module.exports = {
    "extends": ["standard","plugin:jest/recommended"]
};
