import revertByWorld from '../../code/string/lesson1'

test('revertByWorld:Let\'s take LeetCode contest', () => {
  expect(revertByWorld("Let's take LeetCode contest")).toBe("s'teL ekat edoCteeL tsetnoc")
})
